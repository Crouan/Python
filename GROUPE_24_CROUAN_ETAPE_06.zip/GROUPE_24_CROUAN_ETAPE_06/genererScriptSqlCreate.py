f = open('usersToulouse.csv', 'r')  # Ouvrir le fichier en mode lecture
g = open('creerUsersBddAcces.sql', 'w')  # Ouvrir le fichier en mode écriture

# Lecture des mots de passe depuis le fichier usersPassword.csv
passwords = open('usersPassword.csv', 'r').read().splitlines()

# Ignorer la première ligne (en-tête) du fichier CSV
next(f)

for i, ligne in enumerate(f): # 'enumerate' permet d'avoir un indice pour chaque ligne de 'usersToulouse.csv'
    tMots = ligne.strip().split(';')  # Supprimer les espaces et séparer les champs
    prenom = tMots[1][0].lower()  # Première lettre du prénom en minuscule
    nom = tMots[0].lower()  # Nom en minuscule
    login = prenom + nom  # Concaténation du prénom et du nom

    password = passwords[i]  # Utiliser le mot de passe correspondant

    # Création des requêtes SQL pour les différents utilisateurs
    g.write(
        f"CREATE DATABASE IF NOT EXISTS db{login}; "
        f"CREATE USER {login} IDENTIFIED BY '{password}'; "
        f"GRANT ALL PRIVILEGES ON db{login}.* TO {login};\n"

    )

f.close()
g.close()

# Vérifier le contenu du fichier creatUtilisateur
with open('creerUsersBddAcces.sql', 'r') as sql_file:
    for ligne in sql_file:
        print(ligne)
