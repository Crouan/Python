# Importation des modules nécessaires
import csv
import argparse
import re

# Fonction pour vérifier la validité d'un mot de passe
def is_valid_password(password):
    # Vérifie la longueur du mot de passe
    if len(password) < 8 or len(password) > 20:
        return False, "La longueur du mot de passe doit être comprise entre 8 et 20 caractères inclus."

    # Vérifie la présence d'au moins une lettre majuscule
    if not any(char.isupper() for char in password):
        return False, "Le mot de passe doit contenir au moins une lettre majuscule."

    # Vérifie la présence d'au moins une lettre minuscule
    if not any(char.islower() for char in password):
        return False, "Le mot de passe doit contenir au moins une lettre minuscule."

    # Vérifie la présence d'au moins un chiffre
    if not any(char.isdigit() for char in password):
        return False, "Le mot de passe doit contenir au moins un chiffre."

    # Vérifie la présence d'au moins un caractère spécial parmi @, #, $
    if not any(char in '@#$' for char in password):
        return False, "Le mot de passe doit contenir au moins un des caractères spéciaux : @, #, $."

    # Vérifie l'absence de caractères répétitifs consécutifs
    if re.search(r'(.)\1', password):
        return False, "Le mot de passe ne doit pas contenir de caractères répétitifs consécutifs."

    # Si toutes les vérifications passent, le mot de passe est valide
    return True, "Le mot de passe est valide."

# Fonction principale
def main():

    # Configuration de l'analyseur d'arguments en ligne de commande
    parser = argparse.ArgumentParser(description="Programme de validation de mots de passe à partir d'un fichier CSV.")
    parser.add_argument("csv_file", help="Chemin vers le fichier CSV contenant la liste des mots de passe.")
    args = parser.parse_args()

    # Lecture des mots de passe à partir du fichier CSV
    with open(args.csv_file, 'r') as file:
        reader = csv.reader(file)
        passwords = [row[0] for row in reader]

    # Vérifie si il y a des doublons dans la liste
    if len(passwords) != len(set(passwords)):
        print("Erreur : La liste contient des doublons. Veuillez supprimer les doublons et réessayer.")
        return

    # Validation des mots de passe
    for password in passwords:
        is_valid, message = is_valid_password(password)
        print(f"Mot de passe: {password} - {'Valide' if is_valid else 'Invalide'} - {message}")

# Exécution du programme si le fichier est exécuté directement (plutôt que d'être importé comme module)
if __name__ == "__main__":
    main()
