# Ouvrir le fichier d'entrée TestEntrée et le fichier de sortie TestSortie en utilisant un gestionnaire de contexte
with open('TestEntree.csv', 'r') as x, open('TestSortie.csv', 'w') as y:

    # Lire la première ligne du fichier d'entrée (qui est généralement la ligne d'en-tête) et l'ignorer
    next(x)

    # Ajouter le titre de la colonne à la première ligne du fichier de sortie
    y.write("login\n")

    for line in x:  # Lire chaque ligne du fichier d'entrée TestEntrée
        t = line.split(';')  # Diviser la ligne en une liste de mots

        # Prendre la première lettre du premier mot et la concaténer avec le deuxième mot
        mot = t[0][0] + t[1]

        # Convertir le résultat en minuscules
        mot = mot.lower()

        # Écrire le résultat dans le fichier de sortie TestSortie sans sauter de ligne
        y.write(str(mot))

# Les fichiers seront automatiquement fermés lorsque le bloc 'with'

