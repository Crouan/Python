f = open('usersToulouse.csv', 'r')  # Ouvrir le fichier en mode lecture
g = open('supprimerUsersBddAcces.sql', 'w')  # Ouvrir le fichier en mode écriture

# Ignorer la première ligne (en-tête) du fichier CSV
next(f)

for ligne in f:
    tMots = ligne.strip().split(';')  # Supprimer les espaces et séparer les champs
    prenom = tMots[1][0].lower()  # Première lettre du prénom en minuscule
    nom = tMots[0].lower()  # Nom en minuscule
    login = prenom + nom  # Concaténation du prénom et du nom

    # Création des requêtes SQL pour supprimer les utilisateurs et leurs bases de données
    g.write(
        f"DROP DATABASE IF EXISTS db{login}; "
        f"DROP USER IF EXISTS {login};\n"
    )

f.close()
g.close()

# Vérifier le contenu du fichier supprimerUsersBddAcces.sql
with open('supprimerUsersBddAcces.sql', 'r') as sql_file:
    for ligne in sql_file:
        print(ligne)
