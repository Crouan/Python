import csv                                                                              # Importation du module 'csv' pour manipuler des fichiers CSV
import random                                                                           # Importation du module 'random' pour la génération de nombres aléatoires
import string                                                                           # Importation du module 'string' pour manipuler des chaînes de caractères

def generate_password():                                                                # Définition de la fonction 'generate_password' pour créer un mot de passe

    # Liste des caractères autorisés
    uppercase_letters = [char for char in string.ascii_uppercase if char != 'O']
    lowercase_letters = string.ascii_lowercase
    digits = ''.join([str(i) for i in range(1, 10)])                                    # Exclusion de '0' pour éviter la confusion avec 'O'
    special_characters = "!@#$%&*+-=.<>?:" 

    # Génération des composants du mot de passe
    password = random.sample(uppercase_letters, 2) + random.sample(lowercase_letters, 2) + \
               random.sample(digits, 2) + random.sample(special_characters, 2)

    # Mélange aléatoire des composants
    random.shuffle(password)

    # Construction du mot de passe final
    password_str = ''.join(password)

    return password_str

def generate_passwords(num_passwords):                                                  # Définition de la fonction 'generate_passwords' pour créer plusieurs mots de passe
    passwords = set()                                                                   # Utilisation d'un ensemble pour garantir des mots de passe uniques

    while len(passwords) < num_passwords:
        password = generate_password()

        # Vérification des contraintes supplémentaires
        if password[0] in string.ascii_letters and password[-1] in string.ascii_letters:
            passwords.add(password)

    return list(passwords)

def write_to_csv(passwords):                                                              # Définition de la fonction 'write_to_csv' pour écrire les mots de passe dans un fichier CSV
    with open("usersPassword2.csv", "w", newline='') as csvfile:
        fieldnames = ["password"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

        writer.writeheader()
        for password in passwords:
            writer.writerow({"password": password})

if __name__ == "__main__":                                                                # Vérification si le script est exécuté en tant que programme principal
    import sys                                                                            # Importation du module 'sys' pour accéder aux arguments de la ligne de commande

    if len(sys.argv) != 2:
        print("Usage: python createPassword.py <number_of_passwords>")
        sys.exit(1)

    try:
        num_passwords = int(sys.argv[1])
    except ValueError:
        print("Error: Please provide a valid number for the number of passwords.")
        sys.exit(1)

    if num_passwords <= 0:
        print("Error: Number of passwords must be greater than 0.")
        sys.exit(1)

    generated_passwords = generate_passwords(num_passwords)
    write_to_csv(generated_passwords)

    print(f"{num_passwords} passwords generated and saved to usersPassword2.csv.")





