# Ouverture des fichiers en mode lecture et écriture
f = open('usersToulouse.csv', 'r')  # Ouvrir le fichier en mode lecture
g = open('creerUsersBddAcces.sql', 'w')  # Ouvrir le fichier en mode écriture

# Lecture des mots de passe depuis le fichier usersPassword.csv
passwords = open('usersPassword.csv', 'r').read().splitlines()

# Ignorer la première ligne (en-tête) du fichier CSV
next(f)

# Fonction pour supprimer les caractères spéciaux et transformer en majuscules
def nettoyer_nom_utilisateur(nom):
    nom = ''.join(c for c in nom if c.isalpha()).upper()  # Garder uniquement les caractères alphabétiques et convertir en majuscules
    return nom

for i, ligne in enumerate(f): # 'enumerate' permet d'avoir un indice pour chaque ligne de 'usersToulouse.csv'
    tMots = ligne.strip().split(';')  # Supprimer les espaces et séparer les champs
    prenom = ''.join(word[0].lower() for word in tMots[1].replace('-', ' ').replace('_', ' ').split())  # Met la première lettre de chaque prénom en minuscule en remplacant les - _ et espace
    nom = nettoyer_nom_utilisateur(tMots[0])  # prend la valeur de la fonction "nettoyer_nom_utilisateur"
    login = prenom + nom  # Concaténation du prénom et du nom

    password = passwords[i]  # Utiliser le mot de passe correspondant

    # Création des requêtes SQL pour les différents utilisateurs
    g.write(
        f"CREATE DATABASE IF NOT EXISTS db{login}; "
        f"CREATE USER {login} IDENTIFIED BY '{password}'; "
        f"GRANT ALL PRIVILEGES ON db{login}.* TO {login};\n"
    )

f.close()
g.close()

# Vérifier le contenu du fichier creerUsersBddAcces.sql
with open('creerUsersBddAcces.sql', 'r') as sql_file:
    for ligne in sql_file:
        print(ligne)
